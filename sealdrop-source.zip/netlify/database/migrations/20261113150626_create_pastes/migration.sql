CREATE TABLE "pastes" (
	"id" text PRIMARY KEY,
	"ciphertext" text NOT NULL,
	"iv" text NOT NULL,
	"language" text DEFAULT 'plain' NOT NULL,
	"burn_after_reading" boolean DEFAULT false NOT NULL,
	"delete_token" text NOT NULL,
	"size_bytes" integer DEFAULT 0 NOT NULL,
	"views" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone
);
--> statement-breakpoint
CREATE INDEX "pastes_expires_at_idx" ON "pastes" ("expires_at");