import { Hono } from "hono";
import { and, eq, isNotNull, lt, sql } from "drizzle-orm";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { db } from "../../db/index.js";
import { pastes } from "../../db/schema.js";

// Only the API lives on the server; everything else is static files in /public.
export const config = { path: "/api/*" };

const MAX_CIPHERTEXT_CHARS = 1_400_000; // ~1 MB of plaintext once base64-encoded
const EXPIRY_OPTIONS = new Set([600, 3600, 86400, 604800, 2592000]); // seconds
const LANGUAGES = new Set([
  "plain", "markdown", "javascript", "typescript", "python", "go", "rust", "java",
  "c", "cpp", "csharp", "php", "ruby", "shell", "sql", "json", "yaml", "html", "css",
]);
const ID_ALPHABET = "23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ";

function newId(length = 10) {
  const bytes = randomBytes(length);
  let id = "";
  for (const b of bytes) id += ID_ALPHABET[b % ID_ALPHABET.length];
  return id;
}

const hashToken = (token: string) => createHash("sha256").update(token).digest("hex");

function tokenMatches(token: string, storedHash: string) {
  const a = Buffer.from(hashToken(token), "hex");
  const b = Buffer.from(storedHash, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

const isBase64 = (s: unknown): s is string => typeof s === "string" && /^[A-Za-z0-9+/=_-]+$/.test(s);
const isExpired = (expiresAt: Date | null) => expiresAt !== null && expiresAt.getTime() <= Date.now();

const publicMeta = (p: typeof pastes.$inferSelect) => ({
  id: p.id,
  language: p.language,
  burnAfterReading: p.burnAfterReading,
  sizeBytes: p.sizeBytes,
  views: p.views,
  createdAt: p.createdAt,
  expiresAt: p.expiresAt,
});

const app = new Hono();

app.use("/api/*", async (c, next) => {
  await next();
  c.header("Cache-Control", "no-store");
  c.header("X-Content-Type-Options", "nosniff");
});

app.get("/api/health", (c) => c.json({ ok: true }));

app.post("/api/pastes", async (c) => {
  let body: any;
  try {
    body = await c.req.json();
  } catch {
    return c.json({ error: "Invalid JSON body." }, 400);
  }

  const { ciphertext, iv, language = "plain", burnAfterReading = false, expiresIn = 86400, sizeBytes = 0 } = body ?? {};

  if (!isBase64(ciphertext) || ciphertext.length === 0) return c.json({ error: "Missing encrypted content." }, 400);
  if (ciphertext.length > MAX_CIPHERTEXT_CHARS) return c.json({ error: "That paste is too large (1 MB max)." }, 413);
  if (!isBase64(iv) || iv.length > 64) return c.json({ error: "Invalid IV." }, 400);
  if (!LANGUAGES.has(language)) return c.json({ error: "Unsupported language." }, 400);
  if (typeof burnAfterReading !== "boolean") return c.json({ error: "Invalid burn flag." }, 400);
  if (expiresIn !== null && !EXPIRY_OPTIONS.has(expiresIn)) return c.json({ error: "Invalid expiry." }, 400);

  // Opportunistic cleanup of anything that has already expired.
  await db.delete(pastes).where(and(isNotNull(pastes.expiresAt), lt(pastes.expiresAt, new Date())));

  const deleteToken = randomBytes(24).toString("base64url");
  const expiresAt = expiresIn === null ? null : new Date(Date.now() + expiresIn * 1000);

  for (let attempt = 0; attempt < 3; attempt++) {
    const id = newId();
    const inserted = await db
      .insert(pastes)
      .values({
        id,
        ciphertext,
        iv,
        language,
        burnAfterReading,
        deleteToken: hashToken(deleteToken),
        sizeBytes: Number.isFinite(sizeBytes) ? Math.max(0, Math.min(Math.floor(sizeBytes), 2_000_000)) : 0,
        expiresAt,
      })
      .onConflictDoNothing()
      .returning();
    if (inserted.length) {
      return c.json({ ...publicMeta(inserted[0]), deleteToken }, 201);
    }
  }
  return c.json({ error: "Could not allocate an ID, please retry." }, 500);
});

app.get("/api/pastes/:id/meta", async (c) => {
  const [paste] = await db.select().from(pastes).where(eq(pastes.id, c.req.param("id")));
  if (!paste || isExpired(paste.expiresAt)) {
    if (paste) await db.delete(pastes).where(eq(pastes.id, paste.id));
    return c.json({ error: "This paste doesn't exist, has expired, or was already read." }, 404);
  }
  return c.json(publicMeta(paste));
});

// Opening is a POST so link-preview bots that issue GETs can't burn a one-time paste.
app.post("/api/pastes/:id/open", async (c) => {
  const id = c.req.param("id");
  const [current] = await db.select().from(pastes).where(eq(pastes.id, id));
  const gone = () => c.json({ error: "This paste doesn't exist, has expired, or was already read." }, 404);

  if (!current) return gone();
  if (isExpired(current.expiresAt)) {
    await db.delete(pastes).where(eq(pastes.id, id));
    return gone();
  }

  if (current.burnAfterReading) {
    // DELETE ... RETURNING is atomic, so only one reader can ever receive the content.
    const [burned] = await db.delete(pastes).where(eq(pastes.id, id)).returning();
    if (!burned) return gone();
    return c.json({ ...publicMeta(burned), views: burned.views + 1, ciphertext: burned.ciphertext, iv: burned.iv, burned: true });
  }

  const [updated] = await db
    .update(pastes)
    .set({ views: sql`${pastes.views} + 1` })
    .where(eq(pastes.id, id))
    .returning();
  if (!updated) return gone();
  return c.json({ ...publicMeta(updated), ciphertext: updated.ciphertext, iv: updated.iv, burned: false });
});

app.delete("/api/pastes/:id", async (c) => {
  const token = c.req.header("x-delete-token") ?? "";
  const [paste] = await db.select().from(pastes).where(eq(pastes.id, c.req.param("id")));
  if (!paste) return c.json({ ok: true, alreadyGone: true });
  if (!token || !tokenMatches(token, paste.deleteToken)) return c.json({ error: "Invalid delete token." }, 403);
  await db.delete(pastes).where(eq(pastes.id, paste.id));
  return c.json({ ok: true });
});

app.notFound((c) => c.json({ error: "Not found" }, 404));
app.onError((err, c) => {
  console.error(err);
  return c.json({ error: "Something went wrong on our side." }, 500);
});

export default app;
