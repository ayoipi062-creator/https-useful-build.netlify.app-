import { decryptText, findInHistory, removeFromHistory, formatBytes, timeLeft, copy, toast } from "/crypto.js";

const root = document.getElementById("viewer");
const id = location.pathname.split("/").filter(Boolean)[1] || "";
const key = location.hash.slice(1);

const EXT = {
  plain: "txt", markdown: "md", javascript: "js", typescript: "ts", python: "py", go: "go", rust: "rs",
  java: "java", c: "c", cpp: "cpp", csharp: "cs", php: "php", ruby: "rb", shell: "sh", sql: "sql",
  json: "json", yaml: "yml", html: "html", css: "css",
};
const LABEL = {
  plain: "Plain text", markdown: "Markdown", javascript: "JavaScript", typescript: "TypeScript", python: "Python",
  go: "Go", rust: "Rust", java: "Java", c: "C", cpp: "C++", csharp: "C#", php: "PHP", ruby: "Ruby", shell: "Shell",
  sql: "SQL", json: "JSON", yaml: "YAML", html: "HTML", css: "CSS",
};

function envelope({ title, body, gone = false, action }) {
  root.innerHTML = `
    <div class="envelope ${gone ? "gone" : ""}">
      <img class="big-seal" src="/seal.svg" alt="" />
      <h2></h2>
      <p></p>
      <div class="env-actions" style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap"></div>
    </div>`;
  root.querySelector("h2").innerHTML = title;
  root.querySelector("p").innerHTML = body;
  const actions = root.querySelector(".env-actions");
  if (action) actions.appendChild(action);
  const home = document.createElement("a");
  home.className = "btn ghost";
  home.href = "/";
  home.textContent = "Create a new paste";
  actions.appendChild(home);
}

const goneEnvelope = () =>
  envelope({
    title: "Nothing <em>here</em> anymore",
    body: "This paste doesn't exist, has expired, or was burned after someone read it. Ask the sender for a fresh link.",
    gone: true,
  });

async function open() {
  root.innerHTML = `<div class="code-view" style="padding:24px 28px"><div class="skeleton" style="width:50%"></div><div class="skeleton" style="width:80%"></div><div class="skeleton" style="width:65%"></div></div>`;
  const res = await fetch(`/api/pastes/${encodeURIComponent(id)}/open`, { method: "POST" });
  if (res.status === 404) return goneEnvelope();
  if (!res.ok) return envelope({ title: "Couldn't open it", body: "Something went wrong reaching Sealdrop. Try again in a moment." });
  const data = await res.json();

  let text;
  try {
    text = await decryptText({ ciphertext: data.ciphertext, iv: data.iv, key });
  } catch {
    return envelope({
      title: "The key doesn't <em>fit</em>",
      body: data.burned
        ? "The paste was opened but the key in this link is wrong, and because it was set to burn after reading, it's now gone."
        : "The link's key doesn't match this paste. Make sure you copied the whole link, including everything after the #.",
      gone: true,
    });
  }
  if (data.burned) removeFromHistory(id);
  render(text, data);
}

function render(text, meta) {
  const owned = findInHistory(id);
  const isProse = meta.language === "plain" || meta.language === "markdown";
  root.innerHTML = `
    ${meta.burned ? `<div class="burn-banner"><span style="font-size:20px">🔥</span><span><strong>This paste has been destroyed on our side.</strong> This is the only copy now — save what you need before closing the tab.</span></div>` : ""}
    <div class="view-meta">
      <span class="chip">${LABEL[meta.language] || "Plain text"}</span>
      <span class="chip">${text.split("\n").length} lines · ${formatBytes(new TextEncoder().encode(text).byteLength)}</span>
      ${meta.burned ? `<span class="chip hot">burned after reading</span>` : `<span class="chip">${timeLeft(meta.expiresAt)}</span><span class="chip">${meta.views} view${meta.views === 1 ? "" : "s"}</span>`}
      <span class="spacer"></span>
      <button class="btn ghost sm" id="wrap" ${isProse ? "hidden" : ""}>Wrap lines</button>
      <button class="btn ghost sm" id="download">Download</button>
      ${owned && !meta.burned ? `<button class="btn danger sm" id="delete">Delete</button>` : ""}
      <button class="btn sm" id="copy">Copy text</button>
    </div>
    <div class="code-view ${isProse ? "prose" : ""}" id="code"></div>`;

  const code = document.getElementById("code");
  if (isProse) {
    code.textContent = text;
  } else {
    const table = document.createElement("table");
    const tbody = document.createElement("tbody");
    text.split("\n").forEach((line, i) => {
      const tr = document.createElement("tr");
      const ln = document.createElement("td");
      ln.className = "ln";
      ln.textContent = i + 1;
      const lc = document.createElement("td");
      lc.className = "lc";
      lc.textContent = line || " ";
      tr.append(ln, lc);
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    code.appendChild(table);
  }

  document.getElementById("copy").onclick = () => copy(text, "Copied to clipboard");
  document.getElementById("wrap").onclick = (e) => {
    const on = code.classList.toggle("wrap-lines");
    e.currentTarget.textContent = on ? "No wrap" : "Wrap lines";
  };
  document.getElementById("download").onclick = () => {
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `sealdrop-${id}.${EXT[meta.language] || "txt"}`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
  const del = document.getElementById("delete");
  if (del) {
    del.onclick = async () => {
      if (!confirm("Delete this paste for everyone? This can't be undone.")) return;
      const res = await fetch(`/api/pastes/${encodeURIComponent(id)}`, { method: "DELETE", headers: { "x-delete-token": owned.deleteToken } });
      if (!res.ok) return toast("Couldn't delete that paste");
      removeFromHistory(id);
      envelope({ title: "Deleted", body: "The paste is gone for everyone. The link no longer works.", gone: true });
    };
  }
}

async function start() {
  if (!/^[A-Za-z0-9]{4,32}$/.test(id)) return goneEnvelope();
  if (!key) {
    return envelope({
      title: "This link is missing its <em>key</em>",
      body: "Sealdrop links carry their decryption key after the <code>#</code>. It looks like that part got cut off — ask the sender to copy the full link again.",
      gone: true,
    });
  }

  const res = await fetch(`/api/pastes/${encodeURIComponent(id)}/meta`).catch(() => null);
  if (!res) return envelope({ title: "Couldn't reach Sealdrop", body: "Check your connection and reload the page." });
  if (res.status === 404) return goneEnvelope();
  if (!res.ok) return envelope({ title: "Couldn't open it", body: "Something went wrong. Try again in a moment." });
  const meta = await res.json();

  if (!meta.burnAfterReading) return open();

  const owned = findInHistory(id);
  const btn = document.createElement("button");
  btn.className = "btn primary";
  btn.textContent = "Break the seal & read";
  btn.onclick = () => { btn.disabled = true; open(); };
  envelope({
    title: "A one-time <em>message</em>",
    body: `${owned ? "<strong>You created this paste.</strong> Opening it now burns it, and the person you meant it for won't be able to read it. " : ""}This paste will be permanently destroyed the moment you open it. Make sure you're ready to copy what you need. <br/><small style="color:var(--ink-3)">${LABEL[meta.language] || "Plain text"} · ${formatBytes(meta.sizeBytes)} · ${timeLeft(meta.expiresAt)}</small>`,
    action: btn,
  });
}

start();
