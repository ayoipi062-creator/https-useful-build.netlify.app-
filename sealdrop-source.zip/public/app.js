import {
  encryptText, addToHistory, getHistory, removeFromHistory, formatBytes, timeLeft, copy, toast,
} from "/crypto.js";

const $ = (id) => document.getElementById(id);
const form = $("composer");
const content = $("content");
const gutter = $("gutter");
const editor = $("editor");
const submit = $("submit");
const errorEl = $("error");
const result = $("result");
const shareUrl = $("share-url");

const EXT = {
  plain: "txt", markdown: "md", javascript: "js", typescript: "ts", python: "py", go: "go", rust: "rs",
  java: "java", c: "c", cpp: "cpp", csharp: "cs", php: "php", ruby: "rb", shell: "sh", sql: "sql",
  json: "json", yaml: "yml", html: "html", css: "css",
};

function updateEditor() {
  const text = content.value;
  const lines = text.length ? text.split("\n").length : 1;
  gutter.textContent = Array.from({ length: lines }, (_, i) => i + 1).join("\n");
  const bytes = new TextEncoder().encode(text).byteLength;
  $("count").textContent = `${lines} line${lines === 1 ? "" : "s"} · ${formatBytes(bytes)}`;
  gutter.scrollTop = content.scrollTop;
}

function guessLanguage(text) {
  const t = text.trimStart();
  if (/^[{[]/.test(t)) { try { JSON.parse(t); return "json"; } catch {} }
  if (/^#!\/(usr\/)?bin\/(env )?(ba|z)?sh/.test(t)) return "shell";
  if (/^<!doctype html|^<html/i.test(t)) return "html";
  if (/^(def |import \w+$|from \w+ import)/m.test(t) && !/;\s*$/m.test(t)) return "python";
  if (/^package \w+/m.test(t) && /func /.test(t)) return "go";
  if (/\bfn \w+\(|let mut /.test(t)) return "rust";
  if (/^(SELECT|INSERT|UPDATE|CREATE TABLE|WITH)\b/i.test(t)) return "sql";
  if (/\binterface \w+|: (string|number|boolean)\b/.test(t)) return "typescript";
  if (/\b(const|let|function|=>)\b/.test(t)) return "javascript";
  if (/^#{1,6} \w/m.test(t)) return "markdown";
  return null;
}

let languageTouched = false;
$("language").addEventListener("change", () => { languageTouched = true; updateFilename(); });
function updateFilename() { $("filename").textContent = `untitled.${EXT[$("language").value] || "txt"}`; }

content.addEventListener("input", () => {
  updateEditor();
  if (!languageTouched) {
    const g = guessLanguage(content.value);
    if (g) { $("language").value = g; updateFilename(); }
  }
});
content.addEventListener("scroll", () => { gutter.scrollTop = content.scrollTop; });
content.addEventListener("keydown", (e) => {
  if (e.key === "Tab" && !e.shiftKey) {
    e.preventDefault();
    const { selectionStart: s, selectionEnd: end } = content;
    content.setRangeText("  ", s, end, "end");
    updateEditor();
  }
  if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); form.requestSubmit(); }
});

// Drag & drop a text file
["dragenter", "dragover"].forEach((ev) => editor.addEventListener(ev, (e) => { e.preventDefault(); editor.classList.add("drag"); }));
["dragleave", "drop"].forEach((ev) => editor.addEventListener(ev, () => editor.classList.remove("drag")));
editor.addEventListener("drop", async (e) => {
  e.preventDefault();
  const file = e.dataTransfer?.files?.[0];
  if (!file) return;
  if (file.size > 1024 * 1024) return toast("Files up to 1 MB only");
  content.value = await file.text();
  const ext = file.name.split(".").pop()?.toLowerCase();
  const match = Object.entries(EXT).find(([, x]) => x === ext);
  if (match) { $("language").value = match[0]; languageTouched = true; }
  updateFilename();
  updateEditor();
  toast(`Loaded ${file.name}`);
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  errorEl.textContent = "";
  const text = content.value;
  if (!text.trim()) { errorEl.textContent = "Nothing to seal yet — paste something first."; content.focus(); return; }
  if (new TextEncoder().encode(text).byteLength > 1024 * 1024) { errorEl.textContent = "That's over 1 MB. Trim it down and try again."; return; }

  submit.disabled = true;
  submit.innerHTML = '<span class="spinner"></span> Sealing…';
  try {
    const expiryValue = form.querySelector('input[name="expiry"]:checked').value;
    const burnAfterReading = $("burn").checked;
    const language = $("language").value;
    const sealed = await encryptText(text);

    const res = await fetch("/api/pastes", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        ciphertext: sealed.ciphertext, iv: sealed.iv, sizeBytes: sealed.sizeBytes, language, burnAfterReading,
        expiresIn: expiryValue === "never" ? null : Number(expiryValue),
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Upload failed (${res.status})`);

    const url = `${location.origin}/p/${data.id}#${sealed.key}`;
    const firstLine = text.trim().split("\n")[0].slice(0, 60);
    addToHistory({
      id: data.id, key: sealed.key, deleteToken: data.deleteToken, language, burnAfterReading,
      expiresAt: data.expiresAt, createdAt: data.createdAt, sizeBytes: sealed.sizeBytes, title: firstLine,
    });

    shareUrl.value = url;
    $("open-link").href = url;
    $("result-sub").innerHTML = burnAfterReading
      ? "This link works <strong>exactly once</strong>. Opening it yourself will burn it — copy it, don't click it."
      : `Anyone with this link can read it — ${data.expiresAt ? timeLeft(data.expiresAt) : "it never expires, but you can delete it below"}. The key lives after the <code>#</code>.`;
    $("open-link").hidden = burnAfterReading;
    result.hidden = false;
    result.style.animation = "none"; void result.offsetWidth; result.style.animation = "";
    result.scrollIntoView({ behavior: "smooth", block: "center" });
    shareUrl.select();
    renderHistory();
  } catch (err) {
    errorEl.textContent = err.message || "Something went wrong.";
  } finally {
    submit.disabled = false;
    submit.textContent = "Seal & get link";
  }
});

$("copy-link").addEventListener("click", () => copy(shareUrl.value, "Link copied"));
$("new-paste").addEventListener("click", () => {
  content.value = ""; $("burn").checked = false; languageTouched = false;
  $("language").value = "plain"; updateFilename(); updateEditor();
  result.hidden = true; content.focus();
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// ---------- History ----------
async function renderHistory() {
  const list = $("history");
  const items = getHistory();
  if (!items.length) {
    list.innerHTML = `<li class="empty" style="display:block"><strong>No drops yet</strong>Links you create show up here so you can copy or delete them later.</li>`;
    return;
  }
  list.innerHTML = "";
  for (const item of items) {
    const li = document.createElement("li");
    const url = `${location.origin}/p/${item.id}#${item.key}`;
    li.innerHTML = `
      <span class="lang">${EXT[item.language] || "txt"}</span>
      <div style="min-width:0">
        <div class="title"><a href="${url}" target="_blank" rel="noopener"></a></div>
        <div class="sub"></div>
      </div>
      <div class="row-actions">
        <button class="btn ghost sm" data-act="copy">Copy</button>
        <button class="btn danger sm" data-act="delete">Delete</button>
      </div>`;
    li.querySelector(".title a").textContent = item.title || item.id;
    const sub = li.querySelector(".sub");
    const baseSub = [formatBytes(item.sizeBytes || 0), item.burnAfterReading ? "burns on read" : null, timeLeft(item.expiresAt)].filter(Boolean).join(" · ");
    sub.textContent = baseSub;
    if (item.burnAfterReading) li.querySelector(".title a").removeAttribute("target");
    li.querySelector('[data-act="copy"]').onclick = () => copy(url, "Link copied");
    li.querySelector('[data-act="delete"]').onclick = async () => {
      if (!confirm("Delete this paste for everyone? This can't be undone.")) return;
      const res = await fetch(`/api/pastes/${item.id}`, { method: "DELETE", headers: { "x-delete-token": item.deleteToken } });
      if (res.ok) { removeFromHistory(item.id); renderHistory(); toast("Paste deleted"); }
      else toast("Couldn't delete that paste");
    };
    list.appendChild(li);

    // Check whether the paste still exists (expired or burned pastes are gone).
    fetch(`/api/pastes/${item.id}/meta`).then(async (r) => {
      if (r.status === 404) {
        sub.textContent = item.burnAfterReading ? "Read & burned 🔥" : "Expired or deleted";
        li.style.opacity = ".6";
        const del = li.querySelector('[data-act="delete"]');
        del.textContent = "Remove";
        del.onclick = () => { removeFromHistory(item.id); renderHistory(); };
        li.querySelector('[data-act="copy"]').remove();
      } else if (r.ok) {
        const meta = await r.json();
        sub.textContent = `${baseSub} · ${meta.views} view${meta.views === 1 ? "" : "s"}`;
      }
    }).catch(() => {});
  }
}

updateEditor();
renderHistory();
content.focus();
