// Client-side AES-GCM encryption. The key is generated in the browser and
// placed in the URL fragment (#...), which browsers never send to the server.

const enc = new TextEncoder();
const dec = new TextDecoder();

export function toB64url(bytes) {
  let bin = "";
  const arr = new Uint8Array(bytes);
  for (let i = 0; i < arr.length; i += 0x8000) bin += String.fromCharCode(...arr.subarray(i, i + 0x8000));
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export function fromB64url(str) {
  const b64 = str.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((str.length + 3) % 4);
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export async function encryptText(plaintext) {
  const key = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const data = enc.encode(plaintext);
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, data);
  const rawKey = await crypto.subtle.exportKey("raw", key);
  return { ciphertext: toB64url(cipher), iv: toB64url(iv), key: toB64url(rawKey), sizeBytes: data.byteLength };
}

export async function decryptText({ ciphertext, iv, key }) {
  const cryptoKey = await crypto.subtle.importKey("raw", fromB64url(key), "AES-GCM", false, ["decrypt"]);
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromB64url(iv) }, cryptoKey, fromB64url(ciphertext));
  return dec.decode(plain);
}

// --- Local history of pastes created in this browser (never sent anywhere) ---
const HISTORY_KEY = "sealdrop:history";

export function getHistory() {
  try {
    const list = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

export function saveHistory(list) {
  localStorage.setItem(HISTORY_KEY, JSON.stringify(list.slice(0, 50)));
}

export function addToHistory(entry) {
  saveHistory([entry, ...getHistory().filter((e) => e.id !== entry.id)]);
}

export function removeFromHistory(id) {
  saveHistory(getHistory().filter((e) => e.id !== id));
}

export function findInHistory(id) {
  return getHistory().find((e) => e.id === id);
}

export function formatBytes(n) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

export function timeLeft(expiresAt) {
  if (!expiresAt) return "never expires";
  const ms = new Date(expiresAt).getTime() - Date.now();
  if (ms <= 0) return "expired";
  const m = Math.round(ms / 60000);
  if (m < 60) return `expires in ${m} min`;
  const h = Math.round(m / 60);
  if (h < 48) return `expires in ${h} h`;
  return `expires in ${Math.round(h / 24)} days`;
}

export function toast(message) {
  let el = document.querySelector(".toast");
  if (!el) {
    el = document.createElement("div");
    el.className = "toast";
    el.setAttribute("role", "status");
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.classList.remove("show");
  void el.offsetWidth;
  el.classList.add("show");
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove("show"), 2200);
}

export async function copy(text, label = "Copied") {
  try {
    await navigator.clipboard.writeText(text);
    toast(label);
  } catch {
    toast("Copy failed — select and copy manually");
  }
}
