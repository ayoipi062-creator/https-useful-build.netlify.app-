import { pgTable, text, timestamp, boolean, integer, index } from "drizzle-orm/pg-core";

// Pastes are stored encrypted. The server only ever sees ciphertext;
// the decryption key lives in the URL fragment and never leaves the browser.
export const pastes = pgTable(
  "pastes",
  {
    id: text().primaryKey(),
    ciphertext: text().notNull(),
    iv: text().notNull(),
    language: text().notNull().default("plain"),
    burnAfterReading: boolean("burn_after_reading").notNull().default(false),
    deleteToken: text("delete_token").notNull(),
    sizeBytes: integer("size_bytes").notNull().default(0),
    views: integer().notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
  },
  (t) => [index("pastes_expires_at_idx").on(t.expiresAt)],
);
