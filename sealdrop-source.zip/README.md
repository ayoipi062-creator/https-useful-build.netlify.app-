# Sealdrop

Sealdrop is a private pastebin for sharing text and code through a link. Content is encrypted in the
browser before upload. The decryption key lives only in the link's `#fragment`, so the server stores
ciphertext and can't read what you share. Every paste can expire on a timer, and you can set it to burn
after the first read.

## Features

- AES-256-GCM encryption in the browser (Web Crypto API)
- Expiry options: 10 minutes, 1 hour, 1 day, 1 week, 30 days, or never
- Burn after reading: the first open deletes the paste atomically. Link-preview bots can't trigger it
  because opening requires a deliberate click and a POST request.
- Format picker with auto-detection, line numbers, wrap toggle, copy, and download
- Drag and drop a text file into the editor
- "Your drops": a list of links you've created, kept only in this browser's localStorage, showing live
  status and view counts. You can delete your pastes using a private delete token.

## Tech

- **Frontend:** plain HTML, CSS, and ES modules in `public/`. No build step.
- **API:** [Hono](https://hono.dev) running as a Netlify Server (`netlify/server/index.ts`, served on `/api/*`)
- **Storage:** Netlify Database (managed Postgres) through Drizzle ORM. The schema is in `db/schema.ts`
  and migrations are in `netlify/database/migrations/`.

## Run locally

```bash
npm install
netlify dev --port 8889
```

Then open http://localhost:8889.

## Changing the schema

Edit `db/schema.ts`, then run `npx drizzle-kit generate --name <describe_change>`. Netlify applies
migrations automatically on deploy.
