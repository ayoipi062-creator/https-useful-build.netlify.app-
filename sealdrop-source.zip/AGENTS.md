# AGENTS.md — Sealdrop

## What this is
A zero-knowledge pastebin. The browser encrypts content, and the key travels in the URL fragment.
The server must never receive plaintext or keys. Keep it that way in any change.

## Layout
- `public/`: static frontend with no build step. It is the publish directory.
  - `index.html` + `app.js`: the composer, the result card, and the "Your drops" history (localStorage)
  - `view.html` + `view.js`: the viewer. `netlify.toml` rewrites `/p/*` to `view.html`.
  - `crypto.js`: shared helpers for AES-GCM, base64url, local history, toast, and formatting
  - `styles.css`: the full design system (paper/ink/wax-seal palette; Fraunces, Instrument Sans, and JetBrains Mono)
- `netlify/server/index.ts`: the Hono API, exported as the default app, with `config.path = "/api/*"`.
  This must stay the only entry file in `netlify/server/`.
- `db/schema.ts`, `db/index.ts`: the Drizzle schema and client (`drizzle-orm/netlify-db`).
- `netlify/database/migrations/`: generated migrations. Never edit applied ones.

## API
- `POST /api/pastes` takes `{ciphertext, iv, language, burnAfterReading, expiresIn (seconds|null), sizeBytes}`
  and returns meta plus a one-time `deleteToken`. Only the token's SHA-256 hash is stored.
- `GET /api/pastes/:id/meta` returns non-sensitive meta and has no side effects.
- `POST /api/pastes/:id/open` returns the ciphertext. For burn pastes it uses `DELETE … RETURNING`, so
  only one reader can ever win. It is a POST on purpose, so crawlers and link unfurlers can't burn pastes.
- `DELETE /api/pastes/:id` requires the `x-delete-token` header.

## Conventions and decisions
- Expired rows are deleted lazily on read and opportunistically on create. There is no cron yet.
- Allowed languages and expiry values are allow-lists in the server. Keep them in sync with the `<select>`
  and radio options in `index.html` and the `EXT`/`LABEL` maps in the JS.
- Install Drizzle with the `@beta` tag (`drizzle-orm@beta`, `drizzle-kit@beta`).
- Don't add an `index.html`-catching SPA rewrite (`/*`). It would shadow the API server.
